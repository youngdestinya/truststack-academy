import { useState } from 'react';
import Link from 'next/link';
export default function Certificates(){
  const [name, setName] = useState('Chinedu Okoro');
  const [track, setTrack] = useState('Ethical Hacking & Penetration Testing');
  const [date, setDate] = useState('2026-09-15');
  const genId = () => {
    const y = new Date().getFullYear();
    const hex = Math.random().toString(16).slice(2,10).toUpperCase().padEnd(8,'0').slice(0,8);
    return `${y}-${hex}`;
  };
  const [id, setId] = useState('2026-9E43903F');
  function handleGenerate(){ setId(genId()); }
  return (
    <div style={{background:'#fff', minHeight:'100vh', color:'#0a1931', padding:32}}>
      <Link href="/" style={{fontWeight:700}}>← Home</Link>
      <h1 style={{fontSize:42, fontWeight:900, marginTop:24}}>Generate <span className="cert-italic">Certificate</span></h1>
      <p style={{color:'#556'}}>Pure Alegreya Sans except <span className="cert-italic">Certificate</span> italic 900 — ID auto YYYY-HEX8 like 2026-A3F9C12E same as 2026-9E43903F</p>
      <div style={{display:'grid', gridTemplateColumns:'1fr 1.2fr', gap:24, marginTop:24, maxWidth:1100}}>
        <div style={{border:'1px solid #dde5ee', borderRadius:16, padding:20}}>
          <label style={{fontWeight:700, fontSize:13}}>Full Name</label>
          <input value={name} onChange={e=>setName(e.target.value)} style={{width:'100%', padding:'12px 14px', border:'2px solid #0a1931', borderRadius:10, marginTop:6}}/>
          <label style={{fontWeight:700, fontSize:13, marginTop:16, display:'block'}}>Track</label>
          <input value={track} onChange={e=>setTrack(e.target.value)} style={{width:'100%', padding:'12px 14px', border:'2px solid #0a1931', borderRadius:10, marginTop:6}}/>
          <label style={{fontWeight:700, fontSize:13, marginTop:16, display:'block'}}>Date</label>
          <input type="date" value={date} onChange={e=>setDate(e.target.value)} style={{width:'100%', padding:'12px 14px', border:'2px solid #0a1931', borderRadius:10, marginTop:6}}/>
          <div style={{display:'flex', gap:10, marginTop:18}}>
            <button onClick={handleGenerate} style={{background:'#00C6FF', border:0, padding:'12px 16px', borderRadius:10, fontWeight:900}}>Generate ID</button>
            <div style={{padding:'12px 14px', border:'1px dashed #0a1931', borderRadius:10, fontWeight:700}}>{id}</div>
          </div>
          <button style={{marginTop:16, width:'100%', background:'#0a1931', color:'#fff', padding:'12px', borderRadius:10, fontWeight:700}}>Download PNG</button>
        </div>
        <div style={{border:'1px solid #0a1931', borderRadius:16, padding:32, position:'relative', background:'#fff', overflow:'hidden', minHeight:420}}>
          <img src="/Truststack_Logo_PNG.png" style={{position:'absolute', width:600, left:'50%', top:'50%', transform:'translate(-50%,-50%)', opacity:0.06}}/>
          <div style={{position:'relative'}}>
            <div style={{display:'flex', justifyContent:'space-between'}}>
              <div style={{display:'flex', gap:10, alignItems:'center'}}><img src="/Truststack_Logo_PNG.png" style={{width:48}}/><span style={{fontWeight:900}}>TRUSTSTACK ACADEMY</span></div>
              <img src="/Cert_Seal.png" style={{width:180, height:180, objectFit:'contain'}}/>
            </div>
            <div style={{textAlign:'center', marginTop:10}}>
              <div className="cert-italic" style={{fontSize:42}}>Certificate</div>
              <div style={{marginTop:8}}>This certifies that</div>
              <div style={{fontWeight:900, fontSize:28, marginTop:8}}>{name}</div>
              <div style={{marginTop:8}}>has completed</div>
              <div style={{fontWeight:700, fontSize:18, marginTop:8}}>{track}</div>
              <div style={{marginTop:20, display:'flex', justifyContent:'center', gap:40, fontSize:12}}>
                <span>{date}</span><span>{id}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
