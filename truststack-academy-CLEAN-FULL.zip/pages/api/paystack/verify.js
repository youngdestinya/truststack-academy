import fs from 'fs';
import path from 'path';
export default async function handler(req,res){
  if(req.method!=='POST') return res.status(405).json({error:'Method not allowed'});
  const { email, name, track } = req.body;
  const y = new Date().getFullYear();
  const hex = Math.random().toString(16).slice(2,10).toUpperCase().padEnd(8,'0').slice(0,8);
  const id = `${y}-${hex}`;
  const hash_full = [...Array(64)].map(()=> Math.floor(Math.random()*16).toString(16)).join('');
  const blockchain = '0x' + hex + [...Array(32)].map(()=> Math.floor(Math.random()*16).toString(16)).join('');
  try{
    const filePath = path.join(process.cwd(), 'public', 'certs.json');
    const raw = fs.readFileSync(filePath,'utf8');
    const data = JSON.parse(raw);
    data.certificates.push({
      id, student: name || 'New Student', track: track || 'Ethical Hacking & Penetration Testing',
      hash_prefix: hex, hash_full, blockchain_tx: blockchain, blockchain_block: 78492011, status:'VERIFIED', date: new Date().toISOString().slice(0,10), email, signature_valid:true
    });
    data.meta.total = data.certificates.length;
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
  }catch(e){ console.log('File write skipped', e.message); }
  return res.status(200).json({ok:true, id, student: name, track, hash_full, blockchain});
}
