export default function handler(req,res){
  const y = new Date().getFullYear();
  const hex = Math.random().toString(16).slice(2,10).toUpperCase().padEnd(8,'0').slice(0,8);
  const id = `${y}-${hex}`;
  const hash = [...Array(64)].map(()=> Math.floor(Math.random()*16).toString(16)).join('');
  const tx = '0x' + hex + [...Array(32)].map(()=> Math.floor(Math.random()*16).toString(16)).join('');
  return res.status(200).json({id, hash_prefix: hex, hash_full: hash, blockchain: tx, block: 78492011, format:'YYYY-HEX8'});
}
