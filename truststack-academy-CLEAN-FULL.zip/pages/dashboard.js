import { useState } from 'react';
import Link from 'next/link';
const labs = Array.from({length:12}, (_,i)=>({id:i+1, title:`Lab ${i+1}: ${["Recon","Scanning","Exploitation","PrivEsc","Pivoting","Persistence","C2","Forensics","SOC","Cloud","Web","CAP"][i]}`, flag: `flag{${Math.random().toString(16).slice(2,8)}}` }));
export default function Dashboard(){
  const [completed, setCompleted] = useState([]);
  const [active, setActive] = useState(labs[0]);
  const progress = Math.round(completed.length / labs.length * 100);
  return (
    <div style={{background:'#0a0a0a', minHeight:'100vh', color:'#0f0', padding:24, fontFamily:'monospace'}}>
      <Link href="/" style={{color:'#0f0', fontFamily:'Alegreya Sans'}}>← Home</Link>
      <h1 style={{fontFamily:'Alegreya Sans', color:'#fff', fontWeight:900, fontSize:32, marginTop:16}}>LMS v2 — 12 Labs — Terminal Black Green #0f0</h1>
      <div style={{display:'flex', gap:20, marginTop:20, flexWrap:'wrap'}}>
        <div style={{width:260, border:'1px solid #222', borderRadius:12, padding:16, background:'#111'}}>
          <div style={{color:'#fff', fontFamily:'Alegreya Sans', fontWeight:700}}>Progress {progress}%</div>
          <div style={{height:6, background:'#222', borderRadius:999, marginTop:8}}><div style={{width:`${progress}%`, height:'100%', background:'#0f0'}}/></div>
          <div style={{marginTop:16, display:'grid', gap:8}}>
            {labs.map(l=>(
              <button key={l.id} onClick={()=>setActive(l)} style={{textAlign:'left', padding:'10px 12px', borderRadius:8, border: completed.includes(l.id) ? '1px solid #0f0' : '1px solid #333', background: active.id===l.id ? '#0f0' : '#111', color: active.id===l.id ? '#000' : '#0f0', fontWeight:700}}>
                {l.id}. {l.title} {completed.includes(l.id) ? '✓' : ''}
              </button>
            ))}
          </div>
          {progress===100 && <div style={{marginTop:16, padding:10, background:'#0f0', color:'#000', borderRadius:8, fontWeight:900}}>Complete → Generates <span style={{fontFamily:'Alegreya Sans', fontWeight:900, fontStyle:'italic'}}>Certificate</span> 2026-XXXX</div>}
        </div>
        <div style={{flex:1, minWidth:320, border:'1px solid #222', borderRadius:12, background:'#000', padding:16}}>
          <div style={{color:'#0f0'}}>$ lab {active.id} — {active.title}</div>
          <div style={{marginTop:12, background:'#111', padding:12, borderRadius:8, minHeight:200}}>
            <div>root@truststack:~# cat challenge.txt</div>
            <div style={{color:'#fff', marginTop:8}}>Find the flag in /root/flag.txt</div>
            <div style={{marginTop:12}}>Flag format: flag&#123;....&#125;</div>
            <input placeholder="Enter flag" style={{marginTop:16, background:'#000', border:'1px solid #0f0', color:'#0f0', padding:'10px 12px', borderRadius:8, width:'100%'}}/>
            <button onClick={()=>{ if(!completed.includes(active.id)) setCompleted([...completed, active.id])}} style={{marginTop:12, background:'#0f0', color:'#000', padding:'10px 16px', borderRadius:8, fontWeight:900, border:0}}>Submit Flag</button>
          </div>
          <div style={{marginTop:16, color:'#888', fontSize:12}}>Terminal black green #0f0 monospace • Progress tracked file-based • Seal 80px watermark 0.04 QR 120px</div>
        </div>
      </div>
    </div>
  )
}
