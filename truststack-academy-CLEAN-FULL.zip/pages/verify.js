import { useState } from 'react';
import Link from 'next/link';
export default function Verify(){
  const [id, setId] = useState('2026-9E43903F');
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  async function doVerify(){
    setLoading(true);
    try{
      const r = await fetch(`/api/verify/${id.trim().toUpperCase()}`);
      const j = await r.json();
      setData(j);
    }catch(e){ setData({valid:false, error:'Not found'}); }
    setLoading(false);
  }
  return (
    <div style={{background:'#fff', minHeight:'100vh', color:'#0a1931', padding:32}}>
      <Link href="/" style={{fontWeight:700}}>← Home</Link>
      <h1 style={{fontSize:48, fontWeight:900, marginTop:24}}>Verify <span className="cert-italic" style={{fontSize:48}}>Certificate</span></h1>
      <p style={{color:'#556'}}>Pure Alegreya Sans except <span className="cert-italic">Certificate</span> italic 900 32px • Seal 120px flat • Watermark 600px 0.04 • QR 120px</p>
      <div style={{display:'flex', gap:12, marginTop:24, maxWidth:560}}>
        <input value={id} onChange={e=>setId(e.target.value)} placeholder="2026-9E43903F" style={{flex:1, padding:'14px 16px', border:'2px solid #0a1931', borderRadius:10, fontWeight:700, fontFamily:'Alegreya Sans'}}/>
        <button onClick={doVerify} style={{background:'#00C6FF', color:'#0a1931', padding:'0 22px', borderRadius:10, fontWeight:900, border:0}}>{loading?'...':'Verify'}</button>
      </div>
      {data && (
        <div style={{marginTop:28, border:'1px solid #dde5ee', borderRadius:16, padding:24, maxWidth:720, position:'relative', overflow:'hidden', background:'#fff'}}>
          <img src="/Truststack_Logo_PNG.png" style={{position:'absolute', width:600, left:'50%', top:'50%', transform:'translate(-50%,-50%)', opacity:0.06, pointerEvents:'none'}} />
          {data.valid ? (
            <>
              <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', position:'relative'}}>
                <div style={{fontWeight:900, color:'#10b981'}}>VERIFIED • FILE-BASED + BLOCKCHAIN ANCHORED</div>
                <img src="/Cert_Seal.png" alt="seal" style={{width:120, height:120, objectFit:'contain'}}/>
              </div>
              <div style={{marginTop:16, display:'grid', gap:8, fontSize:15, position:'relative'}}>
                <div><b>Student:</b> {data.student}</div>
                <div><b>Track:</b> {data.track}</div>
                <div><b>ID:</b> {data.id}</div>
                <div><b>Hash:</b> <span style={{fontFamily:'monospace', fontSize:12}}>{data.hash_full}</span></div>
                <div><b>Blockchain:</b> <span style={{fontFamily:'monospace', fontSize:12}}>{data.blockchain}</span> • Block {data.block || 78492011}</div>
                <div style={{marginTop:12, display:'flex', gap:12, flexWrap:'wrap'}}>
                  <span style={{fontSize:11, padding:'4px 8px', borderRadius:999, background:'#e6f9ff', border:'1px solid #00C6FF'}}>file_lookup ✓</span>
                  <span style={{fontSize:11, padding:'4px 8px', borderRadius:999, background:'#e6f9ff', border:'1px solid #00C6FF'}}>hash_match ✓</span>
                  <span style={{fontSize:11, padding:'4px 8px', borderRadius:999, background:'#e6f9ff', border:'1px solid #00C6FF'}}>signature_valid ✓</span>
                </div>
              </div>
              <div style={{marginTop:20, padding:16, border:'1px dashed #0a1931', borderRadius:12, position:'relative', background:'#fff'}}>
                <div style={{fontWeight:900, fontSize:13, letterSpacing:2}}>TRUSTSTACK ACADEMY</div>
                <div className="cert-italic" style={{fontSize:32, marginTop:4}}>Certificate</div>
                <div style={{marginTop:8}}>{data.student} • {data.track}</div>
                <div style={{fontSize:11, marginTop:8, color:'#667'}}>{data.id} • {data.hash_prefix} • Seal 80px • Watermark 0.04 • QR 120px</div>
                <img src="/Cert_Seal.png" style={{position:'absolute', right:16, bottom:16, width:80, opacity:0.9}}/>
                <div style={{position:'absolute', left:16, bottom:16, width:120, height:120, border:'1px dashed #94a3b8', display:'grid', placeItems:'center', fontSize:10, color:'#94a3b8'}}>QR 120px</div>
              </div>
            </>
          ) : (
            <div style={{color:'#b91c1c', fontWeight:700}}>NOT FOUND — Check ID 2026-9E43903F</div>
          )}
        </div>
      )}
    </div>
  )
}
