import { useState } from 'react';
import Link from 'next/link';
export default function Pay(){
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [track, setTrack] = useState('Ethical Hacking & Penetration Testing');
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(null);
  async function handlePay(){
    setLoading(true);
    const fakeRef = 'ps_' + Math.random().toString(36).slice(2,10);
    const res = await fetch('/api/paystack/verify', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({reference: fakeRef, email, name, track})});
    const j = await res.json();
    setDone(j);
    setLoading(false);
  }
  return (
    <div style={{background:'#fff', minHeight:'100vh', color:'#0a1931', padding:32}}>
      <Link href="/" style={{fontWeight:700}}>← Home</Link>
      <h1 style={{fontSize:44, fontWeight:900, marginTop:20}}>Pay ₦25k</h1>
      <div style={{maxWidth:480, border:'1px solid #dde5ee', borderRadius:16, padding:22, marginTop:20}}>
        <label style={{fontWeight:700, fontSize:13}}>Email</label>
        <input value={email} onChange={e=>setEmail(e.target.value)} style={{width:'100%', padding:'12px', border:'2px solid #0a1931', borderRadius:10, marginTop:6}}/>
        <label style={{fontWeight:700, fontSize:13, marginTop:14, display:'block'}}>Full Name</label>
        <input value={name} onChange={e=>setName(e.target.value)} style={{width:'100%', padding:'12px', border:'2px solid #0a1931', borderRadius:10, marginTop:6}}/>
        <label style={{fontWeight:700, fontSize:13, marginTop:14, display:'block'}}>Track</label>
        <select value={track} onChange={e=>setTrack(e.target.value)} style={{width:'100%', padding:'12px', border:'2px solid #0a1931', borderRadius:10, marginTop:6}}>
          <option>Ethical Hacking & Penetration Testing</option>
          <option>SOC Analyst & Incident Response</option>
          <option>Network Security & Defense</option>
          <option>Cloud Security AWS/Azure</option>
          <option>Web App Security</option>
          <option>Linux PrivEsc</option>
          <option>Digital Forensics & IR</option>
          <option>SecureSME CAP-ADIT</option>
        </select>
        <button onClick={handlePay} style={{marginTop:18, width:'100%', background:'#0a1931', color:'#fff', padding:'14px', borderRadius:10, fontWeight:900, border:0}}>{loading?'Processing...':'Pay ₦25,000'}</button>
        <p style={{fontSize:12, color:'#667', marginTop:10}}>On success generates ID YYYY-HEX8 appends to certs.json — file-based $0</p>
        {done && <div style={{marginTop:16, padding:12, background:'#e6fff3', border:'1px solid #10b981', borderRadius:10}}><b>Success:</b> ID {done.id} created for {done.student}</div>}
      </div>
    </div>
  )
}
