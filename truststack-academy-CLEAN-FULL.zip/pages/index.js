import Link from 'next/link';
const tracks = [
  "Ethical Hacking & Penetration Testing",
  "SOC Analyst & Incident Response",
  "Network Security & Defense",
  "Cloud Security AWS/Azure",
  "Web App Security",
  "Linux PrivEsc",
  "Digital Forensics & IR",
  "SecureSME CAP-ADIT"
];
export default function Home(){
  return (
    <div style={{background:'#fff', color:'#0a1931', minHeight:'100vh'}}>
      <header style={{display:'flex', alignItems:'center', justifyContent:'space-between', padding:'18px 32px', borderBottom:'1px solid #eef2f7'}}>
        <div style={{display:'flex', alignItems:'center', gap:12}}>
          <img src="/Truststack_Logo_PNG.png" alt="shield" style={{width:40, height:40, objectFit:'contain'}} />
          <span style={{fontWeight:900, fontSize:20, color:'#0a1931'}}>TRUSTSTACK ACADEMY</span>
          <span style={{marginLeft:12, fontSize:10, padding:'4px 8px', border:'1px solid #0a1931', borderRadius:999, fontWeight:700}}>VERCEL FREE $0</span>
        </div>
        <nav style={{display:'flex', gap:20, alignItems:'center', fontWeight:700, fontSize:14}}>
          <Link href="/courses">Courses</Link>
          <Link href="/verify">Verify</Link>
          <Link href="/pay">Pay</Link>
          <Link href="/admin" style={{background:'#D4A72C', color:'#0a1931', padding:'8px 14px', borderRadius:8}}>Admin</Link>
        </nav>
      </header>
      <section style={{padding:'64px 32px', maxWidth:1200, margin:'0 auto'}}>
        <div style={{display:'flex', gap:12, marginBottom:16}}>
          <span style={{background:'#0a1931', color:'#fff', padding:'6px 10px', borderRadius:999, fontSize:11, fontWeight:700}}>FILE-BASED $0</span>
          <span style={{background:'#00C6FF', color:'#0a1931', padding:'6px 10px', borderRadius:999, fontSize:11, fontWeight:700}}>2026-9E43903F VERIFIED</span>
        </div>
        <h1 style={{fontSize:64, lineHeight:'0.95', fontWeight:900, margin:0, color:'#0a1931'}}>Choose Your Track</h1>
        <p style={{fontSize:18, maxWidth:720, marginTop:16, color:'#334'}}>Bundle 8 tracks ₦25k each — Labs, Flags, Terminals. Pure <span style={{fontWeight:900}}>Alegreya Sans</span> except <span className="cert-italic" style={{fontSize:22, color:'#0a1931'}}>Certificate</span> italic 900.</p>
        <div style={{display:'flex', gap:12, marginTop:28}}>
          <Link href="/courses" style={{background:'#0a1931', color:'#fff', padding:'14px 22px', borderRadius:10, fontWeight:700}}>View Courses</Link>
          <Link href="/verify" style={{border:'2px solid #0a1931', color:'#0a1931', padding:'12px 20px', borderRadius:10, fontWeight:700}}>Verify <span className="cert-italic">Certificate</span></Link>
        </div>
      </section>
      <section style={{display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(260px,1fr))', gap:18, padding:'0 32px 80px', maxWidth:1200, margin:'0 auto'}}>
        {tracks.map(t=>(
          <div key={t} style={{border:'1px solid #e6eaf0', borderRadius:14, padding:18, background:'#fff'}}>
            <div style={{fontSize:12, fontWeight:700, color:'#2BA6C4', marginBottom:8}}>6 Weeks • Intermediate • 12 Labs</div>
            <div style={{fontWeight:900, fontSize:18, lineHeight:1.2, color:'#0a1931'}}>{t}</div>
            <div style={{marginTop:12, display:'flex', justifyContent:'space-between', alignItems:'center'}}>
              <span style={{fontWeight:900}}>₦25k</span>
              <Link href="/pay" style={{background:'#00C6FF', color:'#0a1931', padding:'8px 12px', borderRadius:8, fontWeight:700, fontSize:13}}>Enroll</Link>
            </div>
          </div>
        ))}
      </section>
      <footer style={{borderTop:'1px solid #eef2f7', padding:'24px 32px', display:'flex', justifyContent:'space-between', fontSize:13, color:'#667'}}>
        <span>© 2026 Truststack Academy — File-based $0 — Seal 80px • Watermark 0.04</span>
        <span style={{display:'flex', gap:16}}><Link href="/verify">Verify</Link><Link href="/certificates">Certificates</Link><Link href="/dashboard">LMS</Link></span>
      </footer>
    </div>
  )
}
