import Head from 'next/head';
export default function App({ Component, pageProps }) {
  return (
    <>
      <Head>
        <link href="https://fonts.googleapis.com/css2?family=Alegreya+Sans:ital,wght@0,400;0,700;0,900;1,900&display=swap" rel="stylesheet" />
        <style>{`
          * { font-family: 'Alegreya Sans', sans-serif !important; }
          .cert-italic { font-family: 'Alegreya Sans', sans-serif !important; font-weight: 900; font-style: italic; }
          body { background: #ffffff; color: #111; margin:0; }
          a { color: inherit; }
        `}</style>
      </Head>
      <Component {...pageProps} />
    </>
  )
}
