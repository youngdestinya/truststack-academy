import Link from 'next/link';
const tracks = [
  {name:"Ethical Hacking & Penetration Testing", labs:12, weeks:"6 Weeks", level:"Intermediate", price:"₦25k"},
  {name:"SOC Analyst & Incident Response", labs:12, weeks:"6 Weeks", level:"Intermediate", price:"₦25k"},
  {name:"Network Security & Defense", labs:12, weeks:"6 Weeks", level:"Intermediate", price:"₦25k"},
  {name:"Cloud Security AWS/Azure", labs:12, weeks:"6 Weeks", level:"Intermediate", price:"₦25k"},
  {name:"Web App Security", labs:12, weeks:"6 Weeks", level:"Intermediate", price:"₦25k"},
  {name:"Linux PrivEsc", labs:12, weeks:"6 Weeks", level:"Intermediate", price:"₦25k"},
  {name:"Digital Forensics & IR", labs:12, weeks:"6 Weeks", level:"Intermediate", price:"₦25k"},
  {name:"SecureSME CAP-ADIT", labs:12, weeks:"6 Weeks", level:"Intermediate", price:"₦25k"},
];
export default function Courses(){
  return (
    <div style={{background:'#fff', minHeight:'100vh', color:'#0a1931', padding:32}}>
      <Link href="/" style={{fontWeight:700}}>← Home</Link>
      <h1 style={{fontSize:48, fontWeight:900, marginTop:24}}>Courses — 8 Tracks</h1>
      <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(280px,1fr))', gap:20, marginTop:32}}>
        {tracks.map(t=>(
          <div key={t.name} style={{border:'1px solid #dde5ee', borderRadius:16, padding:20}}>
            <div style={{fontSize:12, color:'#2BA6C4', fontWeight:700}}>{t.weeks} • {t.level} • {t.labs} Labs</div>
            <div style={{fontWeight:900, fontSize:20, marginTop:8, lineHeight:1.2}}>{t.name}</div>
            <div style={{marginTop:14, display:'flex', justifyContent:'space-between', alignItems:'center'}}>
              <span style={{fontWeight:900, fontSize:18}}>{t.price}</span>
              <Link href="/pay" style={{background:'#0a1931', color:'#fff', padding:'10px 16px', borderRadius:10, fontWeight:700}}>Enroll</Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
