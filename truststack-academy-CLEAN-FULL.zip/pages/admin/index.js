import { useState } from 'react';
import Link from 'next/link';
const initial = [
  {id:"2026-9E43903F", student:"Chinedu Okoro", track:"Ethical Hacking & Penetration Testing", date:"2026-09-15", hash:"9E43903F"},
  {id:"2026-F5E8A071", student:"Aisha Bello", track:"SOC Analyst & Incident Response", date:"2026-09-18", hash:"F5E8A071"},
];
export default function Admin(){
  const [auth, setAuth] = useState(false);
  const [pass, setPass] = useState('');
  const [certs, setCerts] = useState(initial);
  const [name, setName] = useState('');
  const [track, setTrack] = useState('Ethical Hacking & Penetration Testing');
  const [date, setDate] = useState('2026-09-15');
  function login(){
    if(pass==='truststack2026') setAuth(true);
    else alert('Wrong key');
  }
  function gen(){
    const y = new Date().getFullYear();
    const hex = Math.random().toString(16).slice(2,10).toUpperCase().padEnd(8,'0').slice(0,8);
    const id = `${y}-${hex}`;
    setCerts([...certs, {id, student:name || 'New Student', track, date, hash:hex}]);
    setName('');
  }
  if(!auth){
    return (
      <div style={{minHeight:'100vh', display:'grid', placeItems:'center', background:'#fff', color:'#0a1931'}}>
        <div style={{border:'1px solid #dde5ee', padding:24, borderRadius:16, width:340}}>
          <h2 style={{fontWeight:900}}>Admin Login — CLEAN</h2>
          <p style={{fontSize:13, color:'#667'}}>Key: truststack2026 • No Bearer file</p>
          <input type="password" value={pass} onChange={e=>setPass(e.target.value)} placeholder="Admin key" style={{width:'100%', padding:'12px', border:'2px solid #0a1931', borderRadius:10, marginTop:12}}/>
          <button onClick={login} style={{marginTop:12, width:'100%', background:'#0a1931', color:'#fff', padding:'12px', borderRadius:10, fontWeight:700}}>Enter</button>
          <Link href="/" style={{display:'block', marginTop:12, fontSize:13, textAlign:'center'}}>← Home</Link>
        </div>
      </div>
    )
  }
  return (
    <div style={{background:'#fff', minHeight:'100vh', color:'#0a1931', padding:24}}>
      <Link href="/" style={{fontWeight:700}}>← Home</Link>
      <h1 style={{fontSize:36, fontWeight:900, marginTop:16}}>Admin — CLEAN FIXED — truststack2026</h1>
      <p style={{fontSize:13, color:'#667', maxWidth:760}}>CLEAN without GitHub Bearer. Auto ID 2026-A3F9C12E same format as 2026-9E43903F • File-based $0 • 2 certs preloaded</p>
      <div style={{marginTop:20, border:'1px solid #dde5ee', borderRadius:12, overflow:'hidden', maxWidth:900}}>
        <table style={{width:'100%', borderCollapse:'collapse', fontSize:14}}>
          <thead style={{background:'#f6f8fb', textAlign:'left'}}><tr><th style={{padding:10}}>ID</th><th>Student</th><th>Track</th><th>Date</th><th>Hash</th></tr></thead>
          <tbody>
            {certs.map(c=><tr key={c.id} style={{borderTop:'1px solid #eef2f7'}}><td style={{padding:10, fontWeight:700}}>{c.id}</td><td>{c.student}</td><td>{c.track}</td><td>{c.date}</td><td style={{fontFamily:'monospace', fontSize:12}}>{c.hash}</td></tr>)}
          </tbody>
        </table>
      </div>
      <div style={{marginTop:24, border:'1px solid #dde5ee', borderRadius:16, padding:20, maxWidth:520}}>
        <h3 style={{fontWeight:900}}>Add New — Auto ID 2026-A3F9C12E</h3>
        <label style={{fontSize:12, fontWeight:700}}>Full Name</label>
        <input value={name} onChange={e=>setName(e.target.value)} placeholder="Full Name" style={{width:'100%', padding:'12px', border:'2px solid #0a1931', borderRadius:10, marginTop:6}}/>
        <label style={{fontSize:12, fontWeight:700, marginTop:12, display:'block'}}>Track</label>
        <select value={track} onChange={e=>setTrack(e.target.value)} style={{width:'100%', padding:'12px', border:'2px solid #0a1931', borderRadius:10, marginTop:6}}>
          <option>Ethical Hacking & Penetration Testing</option>
          <option>SOC Analyst & Incident Response</option>
          <option>Network Security & Defense</option>
          <option>Cloud Security AWS/Azure</option>
          <option>Web App Security</option>
          <option>Linux PrivEsc</option>
          <option>Digital Forensics & IR</option>
          <option>SecureSME CAP-ADIT</option>
        </select>
        <label style={{fontSize:12, fontWeight:700, marginTop:12, display:'block'}}>Date</label>
        <input type="date" value={date} onChange={e=>setDate(e.target.value)} style={{width:'100%', padding:'12px', border:'2px solid #0a1931', borderRadius:10, marginTop:6}}/>
        <div style={{marginTop:12, fontSize:12, color:'#667'}}>Format YYYY-HEX8 like 2026-9E43903F → 2026-A3F9C12E • 64 hex hash • blockchain tx 0x... block 78492011</div>
        <button onClick={gen} style={{marginTop:14, background:'#00C6FF', color:'#0a1931', padding:'12px 18px', borderRadius:10, fontWeight:900, border:0}}>Generate & Add Locally</button>
      </div>
    </div>
  )
}
